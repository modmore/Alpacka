Alpacka contains common functionality that is shared between MODX packages developed by modmore. Those other packages require Alpacka to be installed, so it is automatically installed for you when installing such a package.

Packages that depend on Alpacka include:

- ContentBlocks
- Redactor
- MoreGallery

Other packages, including third party packages not developed by modmore, may also depend on Alpacka.
