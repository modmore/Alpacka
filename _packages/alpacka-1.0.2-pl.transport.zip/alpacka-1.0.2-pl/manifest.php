<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Alpacka contains common functionality that is shared between MODX packages developed by modmore. Those other packages require Alpacka to be installed, so it is automatically installed for you when installing such a package.

Packages that depend on Alpacka include:

- ContentBlocks
- Redactor
- MoreGallery

Other packages, including third party packages not developed by modmore, may also depend on Alpacka.
',
    'license' => 'The MIT License (MIT)
Copyright (c) 2016 modmore, a registered brand of Mark Hamstra Web Development

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
',
    'changelog' => 'Alpacka 1.0.2-pl
----------------
Released on 2022-04-21

- Fix fatal error in edge case where modLexicon is not yet loaded as a service

Alpacka 1.0.1-pl
----------------
Released on 2022-04-18

- Fix a few MODX3 incompatibility issues and typehints

Alpacka 1.0.0-pl
----------------
Released on 2018-01-22

- Make sure left-over placeholders are removed in parsePathPlaceholders
- Read assets_url and core_path from settings before using config constants [S9752]

Alpacka 0.4.0-rc2
-----------------
Released on 2016-08-04

- Fix fatal errors on installs that have a renamed core folder

Alpacka 0.4.0-rc1
-----------------
Released on 2016-08-01

- Now available as a MODX Extra (transport package) for shared installations.
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '722515ec16d2981cf46a331725ada3ca',
      'native_key' => 'alpacka',
      'filename' => 'modNamespace/e55e828bab4a99644a3110d37a2ff68d.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'f62c5b30ee33e74de6c7541736d51532',
      'native_key' => 'f62c5b30ee33e74de6c7541736d51532',
      'filename' => 'xPDOFileVehicle/499f977b0a61b53710f02bc1baa1bf99.vehicle',
    ),
  ),
);